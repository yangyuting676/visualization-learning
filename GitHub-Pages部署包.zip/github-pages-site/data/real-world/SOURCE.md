# Gapminder 历史数据摘录

整理者：Jennifer Bryan。上游：Gapminder。

- 数据文件：https://raw.githubusercontent.com/jennybc/gapminder/main/data-raw/08_gap-every-five-years.tsv
- 数据字典：https://jennybc.github.io/gapminder/reference/gapminder.html
- 许可声明：https://raw.githubusercontent.com/jennybc/gapminder/main/DESCRIPTION （CC0）
- 上游入口：https://www.gapminder.org/data/
- 下载日期：2026-10-20
- SHA256：`f74275b4a2f4a7c8e3a09a752f9d6e43d1759d78d5cbfdebaaa3e1a6efc68f78`
- 1704条，142国，5洲，1952—2007，每5年；本地保留完整原始TSV。
- GDP单位仅依数据字典称通胀调整美元/人，未另行宣称PPP基期。统计为历史估计，不是当前全量全球数据。
- 全部图形由tools/generate_data_figures.py确定性计算，不随机添加数据。分组、核密度、排序见assets/data-figures/manifest.json。
