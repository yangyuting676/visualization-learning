# 五章实践公开数据说明

下载日期：2026-10-21。文件原样保留，SHA256与字节数见manifest.json。本模块不使用生成式图像或随机伪造数据。

## Palmer Penguins

- 来源与数据字典：https://allisonhorst.github.io/palmerpenguins/reference/penguins.html
- CSV：https://raw.githubusercontent.com/allisonhorst/palmerpenguins/main/inst/extdata/penguins.csv
- 许可CC0：https://allisonhorst.github.io/palmerpenguins/LICENSE.html
- 整理者：Allison Horst、Alison Hill、Kristen Gorman。原始采集：Palmer Station Antarctica LTER与Kristen Gorman等。
- 原研究：Gorman KB, Williams TD, Fraser WR (2014). Ecological Sexual Dimorphism and Environmental Variability within a Community of Antarctic Penguins. PLoS ONE 9(3), e90081. https://doi.org/10.1371/journal.pone.0090081
- 全部344行、8字段，2007—2009年三个物种、三个岛屿的成年企鹅采样记录。保留NA，不推断为0或新增物种。344不是全球种群数量。
- 字段species、island、sex为名义类别；body_mass_g单位g；bill_length_mm、bill_depth_mm、flipper_length_mm单位mm；year为研究年份。
- 嵌入JS增加source_row，含义是原CSV中从1开始的数据行序号，不声称是原研究的个体ID。数值NA转为null，其余数字保留来源精度。
- 形态四字段完整记录342行；性别有效333行。按物种的原始数为152、68、124，体重有效数为151、68、123。

## NOAA Mauna Loa CO₂

- 资料入口：https://gml.noaa.gov/ccgg/trends/data.html
- 月均说明：https://gml.noaa.gov/ccgg/trends/mlo.html
- 完整CSV：https://gml.noaa.gov/webdata/ccgg/trends/co2/co2_mm_mlo.csv
- 提供者署名：Xin Lan, NOAA/GML；Ralph Keeling, Scripps Institution of Oceanography。源文件说明数据公开使用并请求引用署名；源文件开头的使用说明完整保留。
- 原始下载co2_mm_mlo.csv保留全部文件头、字段和记录，文件创建日期2026-10-09。网页教学只使用2000—2019年连续240个月，子集co2-2000-2019.csv保留year、month、average、deseasonalized、ndays、sdev、unc，不随机抽样。
- average为Mauna Loa站月均大气CO₂浓度，单位ppm；deseasonalized为NOAA发布的季节调整值，本教学不将自定义年度去均值量冒称为此字段。
- 源文件说明插补月以负sdev/unc标记；所选240个月average为正且sdev、unc均非负。源下载中早期缺测标记及2022—2023站点变化说明原样保留，教学选择范围避开该站点变化期间。
- 本教学年/月热图计算average减同年12个月average的算术均值，是教学派生量，并非NOAA官方季节调整。该处理仍可能保留年内趋势，月最大值减最小值不能称为纯季节振幅。站点浓度不等于全球排放量。

## 实施方法

第一章：缺失值审计及有效样本计数；第二章：有效记录按物种分组，均值=体重和/有效记录数，追踪派生表与3个标记；第三章：类别定性、数量顺序色图与明确图例、形状冗余编码；第四章：线性数据到SVG坐标映射，并对342个点做D3二维核密度估计；第五章：同一240月的时间折线与年/月年度去均值热图。

密度方法参考D3官方文档：https://d3js.org/d3-contour/density 。带宽以固定内部SVG像素为单位，改变平滑程度而不改变原始点。密度轮廓不是地形高程、置信区间或因果推断。密度显示只辅助介绍原课程二维映射与等高线，不替代原有Marching Squares讲解。

原Gapminder六类图形对照保留在“基础图形方案对照”入口，原学习记录仍可读取。五章任务使用独立状态，避免旧练习通过状态被错误继承。
