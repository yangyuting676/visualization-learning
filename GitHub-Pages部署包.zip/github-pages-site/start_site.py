"""Start the complete course locally and open it in the default browser."""
from functools import partial
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import threading
import webbrowser

root = Path(__file__).resolve().parent
handler = partial(SimpleHTTPRequestHandler, directory=str(root))
server = None
for port in range(8080, 8100):
    try:
        server = ThreadingHTTPServer(('127.0.0.1', port), handler)
        break
    except OSError:
        continue
if server is None:
    raise SystemExit('Ports 8080-8099 are unavailable. Close an earlier preview and try again.')
url = f'http://127.0.0.1:{server.server_port}/'
print(f'Course website: {url}', flush=True)
print('Keep this window open while studying. Press Ctrl+C to stop.', flush=True)
threading.Timer(.5, lambda: webbrowser.open(url)).start()
try:
    server.serve_forever()
except KeyboardInterrupt:
    pass
finally:
    server.server_close()
