@echo off
setlocal
cd /d "%~dp0"
set "VIS_PYTHON=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"
if exist "%VIS_PYTHON%" (
  "%VIS_PYTHON%" "%~dp0start_site.py"
  goto end
)
where py >nul 2>nul
if not errorlevel 1 (
  py -3 "%~dp0start_site.py"
  goto end
)
where python >nul 2>nul
if not errorlevel 1 (
  python "%~dp0start_site.py"
  goto end
)
echo Python 3 is required. Install Python 3 and try again.
:end
pause
