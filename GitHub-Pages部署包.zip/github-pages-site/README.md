# 可视化导论课程网站

本目录是GitHub Pages发布根目录。首页`index.html`与`assets`、`data`、`lesson-01`至`lesson-05`等文件夹同级，无需构建或安装npm依赖。

## 推荐上传方式

1. 在GitHub创建公开仓库，仓库名可设为`vis-learning`。个人免费账号使用公开仓库启用Pages。
2. 用GitHub Desktop将该仓库克隆到本地。
3. 打开本部署文件夹，将**里面的全部文件和文件夹**复制到克隆的仓库目录。保留仓库自身的`.git`文件夹。
4. 确认仓库最外层能直接看到`index.html`、`assets`、`data`和`.nojekyll`，不要多套一层`github-pages-site`。
5. 在GitHub Desktop中填写提交说明，点击Commit to main，再点击Push origin；新仓库界面也可能显示Publish branch。
6. 打开GitHub仓库的Settings → Pages。Build and deployment下的Source选择Deploy from a branch，Branch选择main，目录选择/(root)，点击Save。
7. 等待部署完成，到Settings → Pages点击Visit site。以GitHub实际显示的地址为准。

项目网站通常为`https://你的GitHub用户名.github.io/vis-learning/`。这里的用户名和仓库名只是格式说明，不是已经生成的可访问网址。

网站文件较多，推荐使用GitHub Desktop一次提交。若使用网页Add file → Upload files，应解压后上传目录内容，并检查所有子目录完整；仅上传ZIP文件不会自动解压成网站。

## 后续更新

替换仓库中的对应网页或资源文件，Commit并Push后，GitHub Pages会再次部署。无需修改原老师的网站仓库。

## 常见问题

- 404：确认Pages选择main和/(root)，且index.html位于仓库最外层；等待部署完成并查看仓库Actions的Pages运行结果。
- 图形或样式缺失：检查assets、data、vendor和五章目录是否全部上传，保持文件名大小写及层级不变。
- 地址打开的是GitHub代码页面：请使用Settings → Pages里的Visit site地址，而非github.com仓库页面。
- 学习进度为空：线上域名与本地网址是不同的浏览器存储环境。需要迁移时，在本地网站导出学习备份，到线上网站导入。每位访问者的笔记保存在自己的浏览器，不会作为公共成绩上传。
- 双击启动网站.cmd和Python脚本只用于本地预览，GitHub Pages不执行Python，也无需执行这些文件。

## 内容及署名

基于李昕老师的原课程网站重构：https://cinger007.github.io/vis/ 。保留原课程内容、案例、讲义与署名。原内容未被重新赋予统一开源许可；第三方代码、图片及数据的来源和许可见THIRD_PARTY.md、vendor内许可证及data内说明。公开展示时继续保留这些说明。

新增27节操作台、内容整理、阅读记录、双语界面和公开数据实践均已包括。原课程文件与配套数据完整保留；原工作目录中的个人笔记和浏览器记录不在本部署包中。

## 官方帮助

- 创建Pages站点：https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site
- 设置发布目录：https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site
