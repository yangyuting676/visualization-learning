/* Share one reproducible dataset across chapter thumbnails and full-size figures. */
(()=>{'use strict';
 const base=new URL('../',document.currentScript.src),atlas=new URL('data-atlas.html',base).href;
 const label=(zh,en)=>`<span data-lang="zh-CN">${zh}</span><span data-lang="en-US" hidden>${en}</span>`;
 const names=['人口层级','人口分组流图','寿命矩阵','经济与寿命气泡图','寿命时间轨迹'];
 const enNames=['Population hierarchy','Population grouping flows','Life expectancy matrix','Economy and longevity bubbles','Life expectancy trajectories'];
 function update(){const en=window.__i18n?.getLocale()==='en-US'||document.documentElement.lang==='en';
  document.querySelectorAll('img[data-real-figure]').forEach(img=>{const src=img.getAttribute('src');if(!src?.includes('/data-figures/'))return;const next=src.replace(/(-en)?\.svg/,en?'-en.svg':'.svg');if(src!==next)img.src=next;const n=Number(src.match(/chapter-0([1-5])/)?.[1]);img.alt=(en?(enNames[n-1]||'Population hierarchy')+' — Gapminder historical data':(names[n-1]||'人口层级')+'——Gapminder公开历史数据');});
  const gallery=document.querySelector('.visual-gallery-heading');if(gallery&&!gallery.querySelector('.real-data-link')){const a=document.createElement('a');a.className='real-data-link';a.href=atlas;a.innerHTML=label('数据来源与高清图','Sources and full-size figures');gallery.append(a);}
  const list=document.querySelector('.academic-reading-list');if(list&&!list.querySelector('.real-data-link')){const p=document.createElement('p');p.className='real-data-link';const a=document.createElement('a');a.href=atlas;a.innerHTML=label('本章配图的数据、计算方法与高清图','Chapter figures: data, methods and full-size views');p.append(a);list.append(p);}
 }
 update();window.addEventListener('load',update);document.addEventListener('wbl:localechange',update);
 const main=document.querySelector('#main');if(main)new MutationObserver(update).observe(main,{childList:true});
})();
