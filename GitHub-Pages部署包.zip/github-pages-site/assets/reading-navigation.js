/* In-section buttons do not alter the hash used by the original chapter router. */
(()=>{
 const e=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 function moveTo(target){if(!target)return;let ancestor=target.parentElement;while(ancestor){if(ancestor.tagName==='DETAILS')ancestor.open=true;ancestor=ancestor.parentElement;}target.classList.add('reading-focus-target');target.setAttribute('tabindex','-1');target.focus({preventScroll:true});target.scrollIntoView({block:'start',behavior:'auto'});}
 document.querySelectorAll('.chapter').forEach(section=>{
  const g=BEGINNER_GUIDES[section.id];if(!g)return;
  const title=section.querySelector('h2'),guide=section.querySelector('.beginner-guide');
  const core=document.createElement('section');core.className='section-keypoint';core.id=section.id+'-core';core.innerHTML=`<strong>学习归纳</strong><p class="guide-idea">${e(g.idea)}</p>`;
  guide.querySelector('.guide-idea')?.remove();guide.querySelector('.guide-body').prepend(core);
  const headings=[...section.querySelectorAll('.tab-panel[data-panel="explain"] h3')].filter(h=>h.dataset.lang!=='en-US');
  const nav=document.createElement('nav');nav.className='section-reading-nav';nav.setAttribute('aria-label','本小节阅读导航');nav.innerHTML=`<span>小节内定位</span><button type="button" data-reading="core">核心结论</button><button type="button" data-reading="connections">知识联系</button><button type="button" data-reading="task">操作与提示</button><button type="button" data-reading="check">理解检查</button>${headings.length?`<details><summary>原课程讲解提纲（${headings.length}项）</summary><div class="reading-heading-buttons">${headings.map((h,k)=>`<button type="button" data-reading-heading="${k}">${e(h.textContent.trim())}</button>`).join('')}</div></details>`:''}`;guide.before(nav);
  nav.querySelectorAll('[data-reading]').forEach(button=>button.onclick=()=>{const kind=button.dataset.reading;const targets={core,connections:section.querySelector('.knowledge-links'),check:section.querySelector('.guide-check'),task:section.querySelector('.guided-task')};if(kind==='task')section.querySelector('.tab-btn[data-tab="demo"]')?.click();moveTo(targets[kind]);});
  nav.querySelectorAll('[data-reading-heading]').forEach(button=>button.onclick=()=>{section.querySelector('.tab-btn[data-tab="explain"]')?.click();let heading=headings[+button.dataset.readingHeading];if(heading.hidden&&heading.nextElementSibling?.dataset.lang==='en-US'&&!heading.nextElementSibling.hidden)heading=heading.nextElementSibling;moveTo(heading);});
 });
})();
