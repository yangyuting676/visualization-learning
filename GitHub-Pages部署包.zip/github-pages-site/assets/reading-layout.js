/* Layout changes preserve original lecture nodes and their event handlers. */
(()=>{
 const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 function portal(){
  const home=document.querySelector('.home-overview');
  if(home&&!home.dataset.layout){
   home.dataset.layout='20';
   const chapters=home.querySelector('.chapter-overview'),heading=chapters?.previousElementSibling;
   if(chapters){heading.classList.add('home-chapters-heading');home.querySelector('.home-heading').after(heading,chapters);}
   const route=home.querySelector('.beginner-entry-route'),resourceBody=home.querySelector('.home-resources-body');if(route&&resourceBody)resourceBody.prepend(route);
   const practice=document.createElement('section');practice.className='home-practice-entry';practice.setAttribute('aria-label','案例与学习工具');practice.innerHTML=`<div class="section-head"><div><h2>结合案例与实践学习</h2><p>学习章节后，通过操作、设计与解释检查理解。</p></div></div><div class="home-practice-links"><a href="#case?step=0"><span>贯穿案例</span><h3>完整案例学习</h3><p>从14条记录出发，完成整理、绘图和解释。</p></a><a href="#fixer"><span>纠错实验</span><h3>图表纠错实验室</h3><p>修改基线、时间与配色，对照图形并解释依据。</p></a><a href="#design?tab=practice"><span>独立应用</span><h3>综合设计与实践</h3><p>使用数据完成图表设计，并检查结论边界。</p></a></div>`;
   chapters?.after(practice);
  }
  const live=document.querySelector('.case-live');if(!live||live.dataset.layout)return;live.dataset.layout='20';
  const visual=document.createElement('section');visual.className='case-visual';visual.setAttribute('aria-label','实时图形与观察结果');
  const controls=document.createElement('section');controls.className='case-operation';controls.setAttribute('aria-label','图形参数与数据操作');controls.innerHTML='<h2>调整数据与图形</h2><p class="tiny muted">修改参数后，可在相邻图形中查看结果。</p>';
  const title=live.querySelector('h2'),intro=title.nextElementSibling;visual.append(title,intro);
  ['#case-chart','#case-axis-feedback','#case-readout','#case-legend'].forEach(s=>visual.append(live.querySelector(s)));
  ['.case-controls','.control-row','#case-input-feedback','#case-data-help'].forEach(s=>controls.append(live.querySelector(s)));
  controls.append(live.querySelector('#case-zero').closest('label'),live.querySelector('.notes-toolbar'));
  const jump=live.querySelector('#jump-to-explain');if(jump)controls.append(jump);
  const help=[...live.children].find(e=>e.matches('p'));if(help)controls.append(help);
  live.append(visual,controls);document.querySelector('.case-layout').prepend(live);
 }
 const main=document.querySelector('#main');if(main){portal();new MutationObserver(portal).observe(main,{childList:true});}
 const lesson=document.querySelector('.lesson-main');if(!lesson)return;
 document.body.classList.add('lesson-reading-layout');
 const chapterNo=Number(location.pathname.match(/lesson-0([1-5])/)[1]),sidebar=lesson.querySelector('.chapter-nav'),originalList=sidebar.querySelector('ul');
 const resources=sidebar.querySelector('.chapter-resources');if(resources){resources.classList.add('chapter-resource-footer');lesson.querySelector('.chapter-content').append(resources);}
 const drawer=document.createElement('details');drawer.className='course-tree-drawer';drawer.id='course-tree-drawer';drawer.open=innerWidth>880;drawer.innerHTML='<summary class="course-tree-toggle">课程目录<span>展开／收起</span></summary><div class="course-tree-body"></div>';
 const tree=drawer.querySelector('.course-tree-body');tree.append(sidebar.querySelector('h3'));tree.querySelector('h3').removeAttribute('data-i18n');
 COURSE.forEach(c=>{
  const group=document.createElement('details');group.className='course-tree-group';group.open=c.id===chapterNo;group.dataset.course=c.id;group.innerHTML=`<summary><span>第${c.id}章</span><strong>${esc(c.title)}</strong></summary>`;
  if(c.id===chapterNo)group.append(originalList);
  else{const list=document.createElement('ul');list.innerHTML=c.sections.map(s=>`<li><a href="../lesson-0${c.id}/index.html#${s.id}">${esc(s.title)}</a></li>`).join('');group.append(list);}
  tree.append(group);
 });sidebar.append(drawer);
 const topbar=document.querySelector('.course-topbar');topbar.querySelector('ul.tabs')?.remove();const path=document.createElement('span');path.className='lesson-breadcrumb';path.setAttribute('aria-label','当前位置');topbar.append(path);
 const outline=document.createElement('aside');outline.className='reading-outline';outline.setAttribute('aria-label','本节标题提纲');lesson.append(outline);
 let pending=false;
 function update(){
  pending=false;const current=lesson.querySelector('.chapter.active');if(!current)return;
  const en=document.documentElement.lang==='en',title=current.querySelector('h2').textContent.trim();path.textContent=`${en?'Course':'课程'} / ${title}`;tree.querySelector('h3').textContent=en?'Course contents':'课程目录';
  sidebar.querySelectorAll('a[data-chapter]').forEach(a=>{if(a.dataset.chapter===current.id)a.setAttribute('aria-current','page');else a.removeAttribute('aria-current');});
  const panel=current.querySelector('.tab-panel.active');const headings=[...(panel?.querySelectorAll('h3')||[])].filter(h=>!h.hidden&&!h.closest('.source-lecture-archive:not([open])')&&!h.closest('[data-lang][hidden]'));
  outline.replaceChildren();const label=document.createElement('p');label.textContent=en?'On this section':'本节提纲';outline.append(label);
  const items=headings.length?headings:[current.querySelector('h2')];items.forEach(h=>{const button=document.createElement('button');button.type='button';button.textContent=h.textContent.trim();button.onclick=()=>{h.setAttribute('tabindex','-1');h.focus({preventScroll:true});h.scrollIntoView({block:'start',behavior:'smooth'});};outline.append(button);});
 }
 function schedule(){if(pending)return;pending=true;requestAnimationFrame(update);}
 const observer=new MutationObserver(schedule);lesson.querySelectorAll('.chapter,.tab-panel').forEach(n=>observer.observe(n,{attributes:true,attributeFilter:['class']}));
 sidebar.querySelectorAll('a[data-chapter]').forEach(a=>a.addEventListener('click',()=>requestAnimationFrame(()=>{update();if(innerWidth<=880){drawer.open=false;const title=lesson.querySelector('.chapter.active h2');title?.setAttribute('tabindex','-1');title?.focus({preventScroll:true});}})));
 document.addEventListener('wbl:localechange',schedule);window.addEventListener('hashchange',schedule);window.addEventListener('pageshow',schedule);matchMedia('(max-width:880px)').addEventListener('change',ev=>drawer.open=!ev.matches);update();
})();
