/* Explicit file-mode reading support; original data demos run through HTTP. */
(()=>{
 const root=new URL('../',document.currentScript.src);
 if(location.protocol!=='file:'){
  const sources=[...document.querySelectorAll('script[type="application/x-vis-module"]')];let pending=sources.length,failed=false;
  document.documentElement.dataset.visModules=pending?'loading':'ready';
  sources.forEach(source=>{
   const script=document.createElement('script');script.type='module';script.async=false;
   if(source.hasAttribute('src'))script.src=source.getAttribute('src');else script.textContent=source.textContent;
   script.onload=()=>{pending--;if(!pending&&!failed)document.documentElement.dataset.visModules='ready';};
   script.onerror=()=>{pending--;document.documentElement.dataset.visModules='failed';if(failed)return;failed=true;const message=document.createElement('aside');message.className='vis-file-notice';message.setAttribute('role','alert');message.textContent='课程交互模块加载失败。请确认网站文件完整，并通过启动程序打开的网站地址访问；修复后刷新页面。';const link=document.createElement('a');link.href=new URL('start-help.html',root).href;link.textContent='查看运行方法';message.append(link);(document.querySelector('.workspace')||document.body).prepend(message);};
   document.head.append(script);
  });
  return;
 }
 document.documentElement.dataset.visModules='file-reading';
 const help=document.createElement('a');help.href=new URL('start-help.html',root).href;help.textContent='查看完整运行方法';
 const chapters=[...document.querySelectorAll('.lesson-main .chapter')];
 if(!chapters.length)return;
 function activate(id){const target=chapters.find(c=>c.id===id)||chapters[0];chapters.forEach(c=>c.classList.toggle('active',c===target));document.querySelectorAll('.chapter-nav a[data-chapter]').forEach(a=>a.classList.toggle('active',a.dataset.chapter===target.id));target.querySelectorAll('.tab-btn').forEach(b=>{b.classList.toggle('active',b.dataset.tab==='explain');b.setAttribute('aria-pressed',String(b.dataset.tab==='explain'));});target.querySelectorAll('.tab-panel').forEach(p=>p.classList.toggle('active',p.dataset.panel==='explain'));}
 document.querySelectorAll('.chapter-nav a[data-chapter]').forEach(a=>a.addEventListener('click',()=>activate(a.dataset.chapter)));
 document.querySelectorAll('.chapter .tab-btn').forEach(b=>b.addEventListener('click',()=>{const section=b.closest('.chapter');section.querySelectorAll('.tab-btn').forEach(el=>{el.classList.toggle('active',el===b);el.setAttribute('aria-pressed',String(el===b));});section.querySelectorAll('.tab-panel').forEach(p=>p.classList.toggle('active',p.dataset.panel===b.dataset.tab));}));
 document.querySelectorAll('.demo-mount,[id^="demo-mount-"]').forEach(mount=>{const message=document.createElement('div');message.className='vis-demo-unavailable';message.innerHTML='<strong>请通过本地服务运行此演示</strong><p>浏览器限制直接从文件加载原课程模块与CSV数据。讲解、代码、导读和学习检查仍可阅读使用。</p>';const link=help.cloneNode(true);message.append(link);mount.replaceChildren(message);});
 window.addEventListener('hashchange',()=>activate(location.hash.slice(1)));activate(location.hash.slice(1));
})();
