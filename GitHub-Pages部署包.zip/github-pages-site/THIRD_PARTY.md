# 来源与第三方依赖

## 原课程

- 网站：https://cinger007.github.io/vis/
- 仓库：https://github.com/cinger007/vis
- 获取日期：2026-10-16
- 获取方式：GitHub main 分支源码压缩包
- 压缩包对应提交：35a66ecb5e35e8c4f2c54a007cb6c590255b6f06
- 原作者署名：李昕，中国石油大学（华东）；主要参考教材：陈为《可视化导论》。

保留 `lesson-01` 至 `lesson-05`、`supplementary`、`i18n.js`、`i18n.css` 中已有的课程内容、数据和演示，在其基础上调整导航、加载行为、样式与部分失效链接。原仓库压缩包未附通用 LICENSE 文件；此处不为原内容另行声明开源许可。使用与分发应保留原作者署名和原有权利说明。本项目供课程作业与学习展示。

## 本地第三方库

- D3 7.9.0，ISC 许可证，见 `vendor/D3-LICENSE.txt`。
  - UMD：`https://cdn.jsdelivr.net/npm/d3@7.9.0/dist/d3.min.js`
  - 自包含 ES module：`https://esm.sh/d3@7.9.0/es2022/d3.bundle.mjs`
  - D3 各子模块在打包文件中的许可证注释保留。
- d3-regression 1.3.10，BSD 3-Clause，见 `vendor/D3-REGRESSION-LICENSE.txt`。
  - `https://unpkg.com/d3-regression@1.3.10/dist/d3-regression.min.js`

新增首页、学习工具、实验室图形采用本地 HTML、CSS、JavaScript、SVG 实现，无视频、远程字体、统计追踪脚本或新图片依赖。


## 本次入门内容的参考资料

27节概念导读、术语定义、合成图书馆案例及检查题为本重构新编写的教学补充。代码与术语核对参考：

- D3 数据绑定：https://d3js.org/d3-selection/joining
- D3 分组聚合：https://d3js.org/d3-array/group
- MDN 数组入门：https://developer.mozilla.org/zh-CN/docs/Learn_web_development/Core/Scripting/Arrays

说明：新增资料保留原课程的主题顺序，不把单选题通过率当作学习效果的实证结论。

图表选型指南的方法参考：英国国家统计局图表选型说明 https://service-manual.ons.gov.uk/data-visualisation/chart-types/choosing-a-chart-type ，以及条形图设计说明 https://service-manual.ons.gov.uk/data-visualisation/chart-types/bar-charts 。本项目的任务结构、交互和案例为课程重构内容。


## 五章任务公开数据

Palmer Penguins: Horst, Hill and Gorman; Palmer Station LTER and original Gorman et al. study. CC0. https://allisonhorst.github.io/palmerpenguins/LICENSE.html

NOAA GML / Scripps Mauna Loa monthly CO2: Xin Lan and Ralph Keeling. Publicly available source data; original use notice retained in data/course-practice/co2_mm_mlo.csv. https://gml.noaa.gov/ccgg/trends/data.html

Source URLs, retrieval date, exact snapshots, data dictionaries and checksums: data/course-practice/SOURCE.md and manifest.json.


## 逐节操作台新增接触数据

SocioPatterns collaboration, Primary school temporal network. https://sociopatterns.org/datasets/primary-school-temporal-network-data/ 。源压缩文件及其72条接触摘录以提供者CC BY-NC-SA条款用于非商业课程作业，摘录保留相同许可。感谢SocioPatterns collaboration。引用Stehlé等2011，doi:10.1371/journal.pone.0023176；Gemmetto等2014，doi:10.1186/s12879-014-0695-9。SHA256、确定性摘录规则和方法边界见data/course-practice/storyline-excerpt.json及逐节演示与资料说明.md。

颜色视觉模拟采用Machado等2009年公开矩阵，doi:10.1109/TVCG.2009.113；官方页面 https://www.inf.ufrgs.br/~oliveira/pubs_files/CVD_Simulation/CVD_Simulation.html 。D3沿用随包ISC许可证。
