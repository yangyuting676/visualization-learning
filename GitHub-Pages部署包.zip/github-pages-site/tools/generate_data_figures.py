"""Reproduce SVG figures from the shipped Gapminder TSV; no random/generated observations.
Run from any directory: python tools/generate_data_figures.py (requires numpy).
"""
from pathlib import Path
import csv, math, json, hashlib, html
from collections import defaultdict
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'assets/data-figures';OUT.mkdir(parents=True,exist_ok=True)
DATA=ROOT/'data/real-world/gapminder-five-year.tsv'
rows=list(csv.DictReader(DATA.open(encoding='utf-8'),delimiter='\t'))
for d in rows:
 for k in ['year','pop']:d[k]=int(d[k])
 for k in ['lifeExp','gdpPercap']:d[k]=float(d[k])
assert len(rows)==1704 and len({d['country'] for d in rows})==142
assert len({(d['country'],d['year']) for d in rows})==1704
assert all(d['pop']>0 and d['gdpPercap']>0 and np.isfinite(d['lifeExp']) for d in rows)
YEARS=sorted({d['year'] for d in rows});assert YEARS==list(range(1952,2008,5))
NOW=[d for d in rows if d['year']==2007];assert len(NOW)==142
GROUPS=['Africa','Americas','Asia','Europe','Oceania']
COLORS=['#527ca1','#4f9389','#b28b55','#8babc4','#316f70'];C=dict(zip(GROUPS,COLORS))
INK='#293f50';MUTED='#657a89';GRID='#dae4e9';BLUE='#46789f';TEAL='#4f9389';AMBER='#b28b55'
GROUP_ZH={'Africa':'非洲','Americas':'美洲','Asia':'亚洲','Europe':'欧洲','Oceania':'大洋洲'}
metrics={'records':len(rows),'countries':len(NOW),'years':YEARS,'population2007':sum(d['pop'] for d in NOW),'groups':{g:sum(d['continent']==g for d in NOW) for g in GROUPS},'sourceSHA256':hashlib.sha256(DATA.read_bytes()).hexdigest()}

class SVG:
 def __init__(self,title,subtitle,en=False,square=False):
  self.en=en;self.w=720 if square else 1440;self.h=720 if square else 640
  self.s=[f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {self.w} {self.h}" role="img"><title>{html.escape(title)}</title><desc>{html.escape(subtitle)}</desc>',f'<rect width="{self.w}" height="{self.h}" fill="#f7fafc"/>','<g font-family="Microsoft YaHei,Segoe UI,Arial,sans-serif">']
  if not square:self.text(36,40,title,26,INK,weight=650);self.text(36,69,subtitle,17,MUTED)
 def text(self,x,y,t,size=18,color=INK,anchor='start',weight=400):self.s.append(f'<text x="{x:.2f}" y="{y:.2f}" font-size="{size}" fill="{color}" text-anchor="{anchor}" font-weight="{weight}">{html.escape(str(t))}</text>')
 def line(self,x1,y1,x2,y2,color=GRID,width=1,opacity=1,dash=''):
  self.s.append(f'<line x1="{x1:.3f}" y1="{y1:.3f}" x2="{x2:.3f}" y2="{y2:.3f}" stroke="{color}" stroke-width="{width}" opacity="{opacity}"'+(f' stroke-dasharray="{dash}"' if dash else '')+'/>')
 def circle(self,x,y,r,color,opacity=1,title='',stroke='none'):
  self.s.append(f'<circle cx="{x:.3f}" cy="{y:.3f}" r="{r:.3f}" fill="{color}" fill-opacity="{opacity}" stroke="{stroke}" stroke-width=".8"><title>{html.escape(title)}</title></circle>')
 def rect(self,x,y,w,h,color,opacity=1,title=''):
  self.s.append(f'<rect x="{x:.3f}" y="{y:.3f}" width="{w:.3f}" height="{h:.3f}" fill="{color}" fill-opacity="{opacity}"><title>{html.escape(title)}</title></rect>')
 def path(self,d,color='none',stroke=BLUE,width=1,opacity=1,title=''):
  self.s.append(f'<path d="{d}" fill="{color}" stroke="{stroke}" stroke-width="{width}" opacity="{opacity}"><title>{html.escape(title)}</title></path>')
 def save(self,name):
  self.s+=['</g></svg>'];(OUT/name).write_text(''.join(self.s),encoding='utf-8')
def polar(cx,cy,r,a):return cx+r*math.cos(a),cy+r*math.sin(a)
def group(g,en):return g if en else GROUP_ZH[g]
def footer(s,en,extra=''):
 s.text(36,617,('Source: Gapminder excerpt / Jennifer Bryan | historical estimates, not current coverage' if en else '来源：Gapminder / Jennifer Bryan 历史数据摘录；统计估计值，并非当前全球全量数据')+extra,15,MUTED)
def chart1(en=False,square=False):
 s=SVG('Population hierarchy · 2007' if en else '人口层级结构 · 2007','142 countries grouped by continent; outer bar length encodes population' if en else '142个国家/地区按洲分组；外环条长编码人口',en,square)
 cx,cy=(360,360) if square else (345,340);r=220 if square else 192
 for rr in [r*.55,r,r+48]:
  s.circle(cx,cy,rr,'none',stroke=GRID)
 ordered=sorted(NOW,key=lambda d:(GROUPS.index(d['continent']),d['country']));angles={d['country']:-math.pi/2+i*2*math.pi/len(ordered) for i,d in enumerate(ordered)}
 for g in GROUPS:
  subset=[d for d in ordered if d['continent']==g];a=np.mean([angles[d['country']] for d in subset]);gx,gy=polar(cx,cy,r*.42,a)
  s.path(f'M {cx} {cy} Q {cx} {gy} {gx:.2f} {gy:.2f}',stroke=C[g],width=3,opacity=.6)
  for d in subset:
   aa=angles[d['country']];x,y=polar(cx,cy,r,aa);mx,my=polar(cx,cy,r*.73,aa)
   s.path(f'M {gx:.2f} {gy:.2f} C {gx:.2f} {gy:.2f} {mx:.2f} {my:.2f} {x:.2f} {y:.2f}',stroke=C[g],width=1.3,opacity=.42)
   s.circle(x,y,3,C[g],.95,f"{d['country']}: {d['pop']:,}")
   bx,by=polar(cx,cy,r+15,aa);ex,ey=polar(cx,cy,r+15+45*d['pop']/max(z['pop'] for z in NOW),aa);s.line(bx,by,ex,ey,C[g],2.8,.85)
  s.circle(gx,gy,9,C[g],1,f'{g}: {len(subset)} countries');lx,ly=polar(cx,cy,r+55,a);s.text(lx,ly,group(g,en),17 if not square else 21,C[g],'middle',600)
 s.circle(cx,cy,16,INK);s.circle(cx,cy,7,'#f7fafc')
 if square:
  s.text(360,44,'142 countries / 2007',23,INK,'middle',600);s.text(360,691,'Gapminder · population hierarchy',19,MUTED,'middle');s.save('hero-atlas'+('-en' if en else '')+'.svg');return
 s.text(765,127,'Largest populations in the excerpt' if en else '摘录中人口最多的国家/地区',22,INK,weight=600)
 top=sorted(NOW,key=lambda d:-d['pop'])[:10];mx=top[0]['pop']
 for i,d in enumerate(top):
  y=169+i*38;s.text(765,y+5,d['country'],18);s.rect(925,y-13,300*d['pop']/mx,19,C[d['continent']],.85);s.text(1240,y+4,f"{d['pop']/1e6:,.1f} M",18,MUTED)
 s.text(765,570,'Ring order is alphabetical, not geographical.' if en else '外环按洲与国家/地区名称排序；不表示地理位置。',17,MUTED)
 footer(s,en);s.save('chapter-01'+('-en' if en else '')+'.svg')
def chart2(en=False):
 s=SVG('Population composition across groups · 2007' if en else '分组变换与人口构成 · 2007','Ribbon width = population; grouping is not migration or longitudinal flow' if en else '带宽表示人口；这是分组构成，不是人口迁徙或时间流动',en)
 gdp=lambda d:0 if d['gdpPercap']<2000 else 1 if d['gdpPercap']<8000 else 2 if d['gdpPercap']<20000 else 3
 life=lambda d:0 if d['lifeExp']<50 else 1 if d['lifeExp']<65 else 2 if d['lifeExp']<75 else 3
 stage=[lambda d:GROUPS.index(d['continent']),gdp,life];names=[[group(g,en) for g in GROUPS],['<2k','2k–8k','8k–20k','≥20k'],['<50','50–65','65–75','≥75']];xs=[100,700,1280];scale=312/metrics['population2007'];pos=[];sizes=[]
 for j in range(3):
  sums=[sum(d['pop'] for d in NOW if stage[j](d)==k) for k in range(len(names[j]))];sizes.append(sums);yy=155;ps=[]
  for val in sums:ps.append(yy);yy+=val*scale+18
  pos.append(ps)
 for j in [0,1]:
  offa=[0.]*len(names[j]);offb=[0.]*len(names[j+1]);matrix=[]
  for a in range(len(names[j])):
   for b in range(len(names[j+1])):
    pop=sum(d['pop'] for d in NOW if stage[j](d)==a and stage[j+1](d)==b);matrix.append(pop)
    if not pop:continue
    h=pop*scale;y1=pos[j][a]+offa[a];y2=pos[j+1][b]+offb[b];x1=xs[j]+18;x2=xs[j+1];mid=(x1+x2)/2
    curve=f'M{x1} {y1} C{mid} {y1} {mid} {y2} {x2} {y2} L{x2} {y2+h} C{mid} {y2+h} {mid} {y1+h} {x1} {y1+h} Z'
    s.path(curve,COLORS[a%5] if j==0 else [BLUE,TEAL,AMBER,'#7999b1'][a],stroke='none',opacity=.35,title=f'{names[j][a]} → {names[j+1][b]}: {pop:,}')
    offa[a]+=h;offb[b]+=h
  assert sum(matrix)==metrics['population2007']
 for j in range(3):
  s.text(xs[j],115,(['Continent','GDP per capita','Life expectancy'][j] if en else ['洲分组','人均GDP分组','预期寿命分组'][j]),22,INK,weight=600)
  for k,name in enumerate(names[j]):
   yy=pos[j][k];h=sizes[j][k]*scale;s.rect(xs[j],yy,18,h,COLORS[k%5]);s.text(xs[j]+27,yy+min(h/2+6,23)+(15 if h<20 else 0),name+(f'  {sizes[j][k]/1e9:.3f} B' if h<20 else ''),18)
   if h>=20:s.text(xs[j]+27,yy+min(h/2+6,23)+20,f'{sizes[j][k]/1e9:.3f} B',15,MUTED)
 s.text(100,577,'GDP: inflation-adjusted US$ / person; life expectancy: years' if en else 'GDP：数据集所用通胀调整美元/人；预期寿命：年；区间左闭右开。',17,MUTED)
 footer(s,en);s.save('chapter-02'+('-en' if en else '')+'.svg')
def ramp(v):
 t=max(0,min(1,(v-23)/60));a=np.array([230,240,239]);b=np.array([39,105,101]);return '#'+''.join(f'{int(x):02x}' for x in a+(b-a)*t)
def chart3(en=False):
 s=SVG('Life expectancy matrix · 1952–2007' if en else '预期寿命矩阵 · 1952—2007','1,704 values; identical lightness scale across five continent panels' if en else '1704条记录；五个洲分面共用同一明度标尺',en)
 lookup={(d['country'],d['year']):d for d in rows}
 for gi,g in enumerate(GROUPS):
  x=35+gi*280;countries=sorted([d for d in NOW if d['continent']==g],key=lambda d:d['lifeExp']);cellh=7.8
  s.text(x,115,group(g,en)+f' / {len(countries)}',22,C[g],weight=600)
  for yi,year in enumerate(YEARS):
   if yi in [0,5,11]:s.text(x+83+yi*15,140,str(year),13,MUTED,'middle')
  for k,d in enumerate(countries):
   y=151+k*cellh
   if k%max(1,len(countries)//7)==0 or len(countries)<=2:s.text(x+73,y+6,d['country'] if len(d['country'])<=12 else d['country'][:10]+'…',11,MUTED,'end')
   for yi,year in enumerate(YEARS):
    v=lookup[d['country'],year]['lifeExp'];s.rect(x+77+yi*15,y,14,7.2,ramp(v),title=f"{d['country']} {year}: {v:.3f} years")
 s.text(39,585,'Years' if en else '寿命（年）',16,MUTED)
 for i in range(240):s.rect(145+i*2,573,2.1,14,ramp(23+60*i/239))
 for v in [23,40,60,83]:s.text(145+(v-23)/60*480,607,str(v),14,MUTED,'middle')
 s.text(700,585,'Countries ordered by 2007 life expectancy within each continent.' if en else '各洲内部按2007年预期寿命排序；浅色低、深色高。',16,MUTED)
 # Source placed at the top right to keep the legend clear.
 s.text(1400,40,'Gapminder / Jennifer Bryan',16,MUTED,'end');s.save('chapter-03'+('-en' if en else '')+'.svg')
def contours(s,xs,ys,z,levels,xmap,ymap):
 # Bilinear marching squares. Ambiguous saddle cells use their centre value.
 for level in levels:
  for j in range(len(ys)-1):
   for i in range(len(xs)-1):
    pp=[(xs[i],ys[j]),(xs[i+1],ys[j]),(xs[i+1],ys[j+1]),(xs[i],ys[j+1])];vv=[z[j,i],z[j,i+1],z[j+1,i+1],z[j+1,i]];hits=[]
    for a,b in [(0,1),(1,2),(2,3),(3,0)]:
     if (vv[a]>=level)!=(vv[b]>=level):
      t=(level-vv[a])/(vv[b]-vv[a]);hits.append((pp[a][0]+t*(pp[b][0]-pp[a][0]),pp[a][1]+t*(pp[b][1]-pp[a][1])))
    if len(hits)==4 and ((sum(vv)/4>=level)!=(vv[0]>=level)):hits=hits[1:]+hits[:1]
    for k in range(0,len(hits)-1,2):s.line(xmap(hits[k][0]),ymap(hits[k][1]),xmap(hits[k+1][0]),ymap(hits[k+1][1]),BLUE,1.5,.55)
def chart4(en=False):
 s=SVG('Economy, health and population · 2007' if en else '经济、寿命与人口 · 2007','142 country bubbles + marginal histograms + smoothed country-density contours' if en else '142个国家/地区气泡、边际直方图与国家/地区分布密度等值线',en)
 xm=lambda x:110+(x-2.4)/2.5*1030;ym=lambda y:540-(y-35)/50*365
 xx=np.array([math.log10(d['gdpPercap']) for d in NOW]);yy=np.array([d['lifeExp'] for d in NOW]);gx=np.linspace(2.4,4.9,72);gy=np.linspace(35,85,52);X,Y=np.meshgrid(gx,gy)
 z=np.exp(-.5*(((X[...,None]-xx)/.22)**2+((Y[...,None]-yy)/4)**2)).mean(axis=-1)
 for y in [40,50,60,70,80]:s.line(110,ym(y),1140,ym(y));s.text(90,ym(y)+6,y,17,MUTED,'end')
 for value in [300,1000,3000,10000,30000]:
  x=xm(math.log10(value));s.line(x,175,x,540);s.text(x,566,f'{value:,}',16,MUTED,'middle')
 contours(s,gx,gy,z,[z.max()*v for v in [.2,.4,.6,.8]],xm,ym)
 for d in sorted(NOW,key=lambda d:-d['pop']):
  x=xm(math.log10(d['gdpPercap']));y=ym(d['lifeExp']);radius=28*math.sqrt(d['pop']/max(t['pop'] for t in NOW));s.circle(x,y,radius,C[d['continent']],.62,f"{d['country']} | GDP {d['gdpPercap']:.2f} | life {d['lifeExp']:.3f} | pop {d['pop']:,}",stroke='#fff')
 counts,edges=np.histogram(xx,bins=np.linspace(2.4,4.9,27))
 for c,a,b in zip(counts,edges[:-1],edges[1:]):s.rect(xm(a),158-65*c/max(counts),max(1,xm(b)-xm(a)-2),65*c/max(counts),BLUE,.7)
 counts,edges=np.histogram(yy,bins=np.linspace(35,85,21))
 for c,a,b in zip(counts,edges[:-1],edges[1:]):s.rect(1160,ym(b),90*c/max(counts),max(1,ym(a)-ym(b)-2),TEAL,.7)
 for name in ['China','India','United States','Japan','Nigeria']:
  d=next(d for d in NOW if d['country']==name);x=xm(math.log10(d['gdpPercap']));y=ym(d['lifeExp']);s.text(x+10,y-14,name,17,INK,weight=600)
 s.text(110,126,'Life expectancy / years' if en else '预期寿命 / 年',18,INK);s.text(630,595,'GDP per capita · log scale · inflation-adjusted US$' if en else '人均GDP · 对数坐标 · 通胀调整美元/人',18,MUTED,'middle')
 s.text(1280,210,'Population' if en else '人口面积',17,INK);s.circle(1315,269,28*math.sqrt(1e9/max(t['pop'] for t in NOW)),TEAL,.5);s.text(1280,310,'1 B',16,MUTED);s.circle(1315,356,28*math.sqrt(1e8/max(t['pop'] for t in NOW)),TEAL,.5);s.text(1280,389,'100 M',16,MUTED)
 s.text(1280,450,'142',31,INK,weight=650);s.text(1280,477,'countries' if en else '国家/地区',17,MUTED)
 for i,g in enumerate(GROUPS):s.circle(1286,513+i*18,4,C[g]);s.text(1297,518+i*18,group(g,en),13,MUTED)
 footer(s,en);s.save('chapter-04'+('-en' if en else '')+'.svg')
def chart5(en=False):
 s=SVG('Life expectancy trajectories · 1952–2007' if en else '预期寿命时间轨迹 · 1952—2007','All 142 country series; selected countries highlighted without smoothing' if en else '142条完整国家/地区序列；突出五个国家/地区，不进行平滑或插补',en)
 xm=lambda y:90+(y-1952)/55*830;ym=lambda v:535-(v-20)/65*390
 for v in [20,40,60,80]:s.line(90,ym(v),920,ym(v));s.text(73,ym(v)+6,v,17,MUTED,'end')
 for yr in [1952,1962,1972,1982,1992,2007]:s.text(xm(yr),565,yr,17,MUTED,'middle')
 selected={'China':BLUE,'India':TEAL,'United States':AMBER,'Brazil':'#82a8c0','South Africa':'#385e76'};by=defaultdict(list)
 for d in rows:by[d['country']].append(d)
 for name,seq in by.items():
  seq.sort(key=lambda d:d['year']);pts=' '.join(('M' if i==0 else 'L')+f"{xm(d['year']):.2f} {ym(d['lifeExp']):.2f}" for i,d in enumerate(seq));s.path(pts,stroke=selected.get(name,'#8b9caa'),width=2.8 if name in selected else 1,opacity=1 if name in selected else .18,title=name)
 for i,(name,col) in enumerate(selected.items()):s.line(92+i*175,110,113+i*175,110,col,3);s.text(120+i*175,116,name,15,col)
 s.text(1040,115,'Largest increases' if en else '寿命增幅前十五位',21,INK,weight=600);s.text(1040,139,'2007 − 1952 / years' if en else '2007减1952 / 年',16,MUTED)
 gains=sorted([(seq[-1]['lifeExp']-seq[0]['lifeExp'],name) for name,seq in by.items()],reverse=True)[:15]
 for i,(v,name) in enumerate(gains):
  yy=173+i*25;s.text(1163,yy+5,name,12 if len(name)>16 else 14,MUTED,'end');s.line(1176,yy,1176+v*4,yy,GRID,2);s.circle(1176+v*4,yy,4,TEAL);s.text(1360,yy+5,f'{v:.1f}',14,INK)
 s.text(90,594,'Equal 5-year spacing; country estimates do not identify individual outcomes or causes.' if en else '观测间隔均为五年；国家/地区层面的统计估计不能替代个体结论或因果判断。',17,MUTED)
 footer(s,en);s.save('chapter-05'+('-en' if en else '')+'.svg')

for en in [False,True]:
 chart1(en);chart1(en,True);chart2(en);chart3(en);chart4(en);chart5(en)
metrics['figures']=12
metrics['license']='Jennifer Bryan gapminder package: CC0 (DESCRIPTION); underlying origin: Gapminder.org'
metrics['source']='https://raw.githubusercontent.com/jennybc/gapminder/main/data-raw/08_gap-every-five-years.tsv'
metrics['documentation']='https://jennybc.github.io/gapminder/reference/gapminder.html'
metrics['retrieved']='2026-10-20'
metrics['methods']={'chapter1':'2007 hierarchy by continent; country nodes alphabetical; radius=1.2+5*sqrt(pop/maxpop), outer bars linear population; right bars are top ten populations. Node sizes are a visibility-adjusted cue, not exact proportional area.','chapter2':'2007 population cross-tabulation: continent -> GDP bins [0,2000,8000,20000,inf) -> life bins [0,50,65,75,inf). Both edge layers conserve the excerpt population; not migration.','chapter3':'All 1704 lifeExp values; common domain [23,83], one panel per continent, countries sorted by 2007 lifeExp. Labels are sampled, cells are not.','chapter4':'2007 x=log10(gdpPercap), y=lifeExp; bubble area exactly proportional to pop; KDE in log-GDP/life coordinates, Gaussian bandwidths 0.22 log10 units and 4 years, no population weights; 72x52 grid, contours at .2,.4,.6,.8 of maximum; marginal histograms count countries.','chapter5':'All country trajectories, linear joins at 12 five-year observations; no interpolation of missing years; right panel ranks 2007 minus 1952 life expectancy.'}
metrics['methods']['chapter1']='2007 hierarchy by continent; country nodes alphabetical and equal-sized; outer bar lengths linearly proportional to population; right bars show the ten largest populations in this excerpt. Position is not geographical.'
(OUT/'manifest.json').write_text(json.dumps(metrics,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(metrics,ensure_ascii=False,indent=2))
