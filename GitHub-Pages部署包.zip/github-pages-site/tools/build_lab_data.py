"""Embed the exact shipped TSV for offline browser experiments. Python stdlib only."""
from pathlib import Path
import csv,json,hashlib
r=Path(__file__).resolve().parents[1];source=r/'data/real-world/gapminder-five-year.tsv'
rows=list(csv.DictReader(source.open(encoding='utf-8'),delimiter='\t'))
for row in rows:
 for k in ['year','pop']:row[k]=int(row[k])
 for k in ['lifeExp','gdpPercap']:row[k]=float(row[k])
assert len(rows)==1704 and len({d['country'] for d in rows})==142
digest=hashlib.sha256(source.read_bytes()).hexdigest()
(r/'assets/course-lab-data.js').write_text('/* Exact TSV records embedded for file-mode experiments. SHA256 '+digest+' */\nwindow.COURSE_LAB_DATA='+json.dumps(rows,ensure_ascii=False,separators=(',',':'))+';\n',encoding='utf-8')
print('Embedded 1704 source records, SHA256',digest)
